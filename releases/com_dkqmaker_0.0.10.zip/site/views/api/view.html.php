<?php
defined('_JEXEC') or die('Restricted access');

/**
 * Placeholder view for enabling SEF URLs
 *
 * @since  2.0.1
 */
class DKQMakerViewApi extends JViewLegacy
{
}
