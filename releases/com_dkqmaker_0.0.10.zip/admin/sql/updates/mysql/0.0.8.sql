/* add image to question */
ALTER TABLE `#__questions` ADD COLUMN `image` VARCHAR(255);