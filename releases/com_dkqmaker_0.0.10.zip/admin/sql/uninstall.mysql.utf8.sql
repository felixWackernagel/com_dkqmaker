DROP TABLE IF EXISTS `#__quizzes`;
DROP TABLE IF EXISTS `#__questions`;
DROP TABLE IF EXISTS `#__dkq_messages`;
DROP TABLE IF EXISTS `#__dkq_quizzers`;
