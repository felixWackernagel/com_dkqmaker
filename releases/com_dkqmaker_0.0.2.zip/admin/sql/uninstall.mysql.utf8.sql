DROP TABLE IF EXISTS `#__quizzes`;
DROP TABLE IF EXISTS `#__questions`;
