<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
        <td colspan="8"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>
